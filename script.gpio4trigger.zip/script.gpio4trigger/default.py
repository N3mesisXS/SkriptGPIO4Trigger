#!/usr/bin/env python
# -*- coding: utf-8 -*-

# GPIO4-Trigger

import os
import sys
import xbmc, xbmcgui, xbmcaddon, xbmcvfs
from time import sleep



__author__ = 'Steven'

ADDON = xbmcaddon.Addon()
ADDONNAME = ADDON.getAddonInfo('name')
ADDONID = ADDON.getAddonInfo('id')
ADDONPATH = ADDON.getAddonInfo('path')
ADDONVERSION = ADDON.getAddonInfo('version')
ADDON_USERPATH = os.path.join(xbmc.translatePath('special://userdata'), 'addon_data', ADDONID)

GPIO04TRUE = os.path.join(ADDON_USERPATH, 'GPIO04_TRUE.log')
GPIO04FALSE = os.path.join(ADDON_USERPATH, 'GPIO04_FALSE.log')

# Setup of the GPIO4-Trigger
# Dateien erst als Sudo su erstellen, testen, dann erst die Dateirechte aendern.
def gpio4_setup():
    os.system("chmod 222 /sys/class/gpio/export /sys/class/gpio/unexport")
    os.system("echo \"4\" > /sys/class/gpio/export")
    os.system("chmod 222 /sys/class/gpio/gpio4/direction")
    os.system("chmod 222 /sys/class/gpio/gpio4/value")
    os.system("echo \"4\" > /sys/class/gpio/gpio4/direction")

# Trigger
def gpio4_trigger():
    #userfolder = xbmcvfs.exists(ADDON_USERPATH)
    
    #xbmcgui.Dialog().ok(ADDONNAME, "START!", str(userfolder), ADDON_USERPATH)
    
    if not xbmcvfs.exists(ADDON_USERPATH):
        xbmcvfs.mkdir(ADDON_USERPATH)
        #with open(GPIO04FALSE, 'w') as neueDatei:
        #    neueDatei.close()
    #sleep(5)
    
    valueFile_False = os.path.isfile(GPIO04FALSE)

    #xbmcgui.Dialog().ok(ADDONNAME, "FALSE FILE", str(valueFile_False), "Sie koennen jederzeit ein Backup im Addonverzeichnis ablegen.")

    if not os.path.isfile(GPIO04FALSE):
        
        os.system("echo \"0\" > /sys/class/gpio/gpio4/value")
        #xbmcgui.Dialog().ok(ADDONNAME, str(os.path.isfile(GPIO04FALSE)), "Datei GPIO04FALSE erstellt", "Sie koennen jederzeit ein Backup im Addonverzeichnis ablegen.")

        with open(GPIO04FALSE, 'w') as neueDatei:
            neueDatei.close()
        try:
            os.remove(GPIO04TRUE)
        except OSError:
            pass

        return None
                
        #sleep(10)
    #xbmcgui.Dialog().ok(ADDONNAME, "RETURN_1", "Datei GPIO04FALSE erstellt", "Sie koennen jederzeit ein Backup im Addonverzeichnis ablegen.")
        

    if not os.path.isfile(GPIO04TRUE):
        #os.remove(GPIO04FALSE)
        os.system("echo \"1\" > /sys/class/gpio/gpio4/value")
        #xbmcgui.Dialog().ok(ADDONNAME, str(os.path.isfile(GPIO04TRUE)), "Datei GPIO04TRUE erstellt", "Sie koennen jederzeit ein Backup im Addonverzeichnis ablegen.")

        with open(GPIO04TRUE, 'w') as neueDatei:
            neueDatei.close()
        try:
            os.remove(GPIO04FALSE)
        except OSError:
            pass
        
        return None

    #xbmcgui.Dialog().ok(ADDONNAME, "RETURN_2", "Datei GPIO04FALSE erstellt", "Sie koennen jederzeit ein Backup im Addonverzeichnis ablegen.")


#    pin = os.system("cat /sys/class/gpio/gpio4/value")


#    if(pin == "1"):
#        os.system()
#        log("GPIO inaktiv.")
#    elif(pin == "0"):
#     os.system()
#        log("GPIO aktiv.")


def main():
    #gpio4_setup()
    gpio4_trigger()
    return


if __name__ == '__main__':
    main()
