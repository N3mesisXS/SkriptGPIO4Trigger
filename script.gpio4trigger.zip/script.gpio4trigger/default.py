#!/usr/bin/env python
# -*- coding: utf-8 -*-

# GPIO4-Trigger

import os
import sys
import xbmc, xbmcgui, xbmcaddon



__author__ = 'Steven'

ADDON = xbmcaddon.Addon()
ADDONNAME = ADDON.getAddonInfo('name')
ADDONID = ADDON.getAddonInfo('id')
ADDONPATH = ADDON.getAddonInfo('path')
ADDONVERSION = ADDON.getAddonInfo('version')

# Setup of the GPIO4-Trigger
def gpio4_setup()
    os.system("chmod 222 /sys/class/gpio/export /sys/class/gpio/unexport")
    os.system("echo \"4\" > /sys/class/gpio/export")
    os.system("chmod 222 /sys/class/gpio/gpio4/direction")
    os.system("chmod 222 /sys/class/gpio/gpio4/value")
    os.system("echo \"4\" > /sys/class/gpio/gpio4/direction")

# Trigger
def gpio4_trigger()
    pin = os.system("cat /sys/class/gpio/gpio4/value")
    if(pin == "1"):
        os.system("echo \"0\" > /sys/class/gpio/gpio4/value")
        log("GPIO inaktiv.")
    elif(pin == "0"):
        os.system("echo \"1\" > /sys/class/gpio/gpio4/value")
        log("GPIO aktiv.")


def main():
    #gpio4_setup()
    gpop4_trigger()


if __name__ == '__main__':
    main()
